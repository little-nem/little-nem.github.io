#ifndef EXAMPLES_DEF
#define EXAMPLES_DEF

void cards();
void bar_shapes();

#endif